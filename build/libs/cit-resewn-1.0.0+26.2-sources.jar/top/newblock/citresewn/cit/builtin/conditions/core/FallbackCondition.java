package top.newblock.citresewn.cit.builtin.conditions.core;

import top.newblock.citresewn.fletchingtable.api.Entrypoint;
import top.newblock.citresewn.api.CITConditionContainer;
import top.newblock.citresewn.api.CITGlobalProperties;
import top.newblock.citresewn.cit.CIT;
import top.newblock.citresewn.cit.builtin.conditions.IdentifierCondition;
import top.newblock.citresewn.pack.format.PropertyValue;

import java.util.*;
import net.minecraft.resources.Identifier;

/**
 * Core property used to set the fallback of the CIT.<br>
 * When a CIT loads successfully, its fallback CIT gets removed prior to activation.<br>
 * If the main CIT fails to load(or if not loaded at all) the fallback loads as usual.
 * @see #apply(List)
 * @see #globalProperty(String, PropertyValue)
 */
public class FallbackCondition extends IdentifierCondition {
    @Entrypoint(CITConditionContainer.ENTRYPOINT)
    public static final CITConditionContainer<FallbackCondition> CONTAINER = new CITConditionContainer<>(FallbackCondition.class, FallbackCondition::new,
            "cit_fallback", "citFallback");

    public FallbackCondition() {
        this.value = null;
    }

    public Identifier getFallback() {
        return this.value;
    }

    public void setFallback(Identifier value) {
        this.value = value;
    }

    /**
     * @see #globalProperty(String, PropertyValue)
     */
    private static boolean fallbackCITResewnRoot = false;

    /**
     * When the global property "citresewn:root_fallback" is set to true, all CITs in the "citresewn"
     * root will automatically have the fallback to the same path in the other roots(optifine/mcpatcher).<br>
     * This behavior is overridden if the CIT specifies a {@link FallbackCondition fallback} manually.
     * @see #apply(List)
     */
    @Entrypoint(CITGlobalProperties.ENTRYPOINT)
    public static void globalProperty(String key, PropertyValue value) throws Exception {
        if (key.equals("root_fallback"))
            fallbackCITResewnRoot = value != null && Boolean.parseBoolean(value.value());
    }

    /**
     * Removes fallback {@link CIT CITs} of all successfully loaded CITs in the given list.<br>
     * @see #globalProperty(String, PropertyValue)
     */
    public static void apply(List<CIT<?>> cits) {
        Map<String, Set<Identifier>> removePacks = new HashMap<>();

        for (CIT<?> cit : cits) {
            Set<Identifier> remove = removePacks.computeIfAbsent(cit.packName, s -> new HashSet<>());
            if (cit.fallback == null) {
                if (fallbackCITResewnRoot && cit.propertiesIdentifier.getPath().startsWith("citresewn/")) {
                    String subPath = cit.propertiesIdentifier.getPath().substring(10);
                    remove.add(Identifier.fromNamespaceAndPath(cit.propertiesIdentifier.getNamespace(), "optifine/" + subPath));
                    remove.add(Identifier.fromNamespaceAndPath(cit.propertiesIdentifier.getNamespace(), "mcpatcher/" + subPath));
                }
            } else {
                remove.add(cit.fallback);
            }
        }

        cits.removeIf(cit -> {
            Set<Identifier> remove = removePacks.get(cit.packName);
            return remove != null && remove.contains(cit.propertiesIdentifier);
        });
    }
}
